﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using AgileTool.Controllers;
using AgileTool.Models;

namespace AgileTool.GUI
{
    public partial class Form1 : Form
    {
        // ==========================================
        // Create controllers at the top
        // ==========================================
        private ProjectController projectController =
                new ProjectController();
        private PersonController personController =
                new PersonController();
        private UserStoryController userStoryController =
                new UserStoryController();
        private TaskController taskController =
                new TaskController();
        private ProjectTeamController teamController =
                new ProjectTeamController();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // ==========================================
        // PROJECTS BUTTON
        // ==========================================
        private void btnProject_Click(object sender, EventArgs e)
        {
            listBoxMain.Items.Clear();
            listBoxMain.Items.Add("=== All Projects ===");

            List<Project> projects =
                projectController.GetAllProjects();

            if (projects.Count == 0)
            {
                listBoxMain.Items.Add("No projects found!");
                return;
            }

            foreach (Project p in projects)
            {
                listBoxMain.Items.Add(
                    p.Id + ". " + p.Name +
                    " - " + p.Description);
            }
        }

        // ==========================================
        // PERSONS BUTTON
        // ==========================================
        private void btnPersons_Click(object sender, EventArgs e)
        {
            listBoxMain.Items.Clear();
            listBoxMain.Items.Add("=== All Persons ===");

            List<Person> persons =
                personController.GetAllPersons();

            if (persons.Count == 0)
            {
                listBoxMain.Items.Add("No persons found!");
                return;
            }

            foreach (Person p in persons)
            {
                listBoxMain.Items.Add(
                    p.Id + ". " + p.Name +
                    " - Role: " + p.Role);
            }
        }

        // ==========================================
        // USER STORIES BUTTON
        // ==========================================
        private void button3_Click(object sender, EventArgs e)
        {
            listBoxMain.Items.Clear();
            listBoxMain.Items.Add("=== All User Stories ===");

            List<UserStory> stories =
                userStoryController.GetAllStories();

            if (stories.Count == 0)
            {
                listBoxMain.Items.Add("No stories found!");
                return;
            }

            foreach (UserStory s in stories)
            {
                listBoxMain.Items.Add(
                    s.Id + ". " + s.Description +
                    " - State: " + s.GetStateName() +
                    " - Priority: " + s.Priority);
            }
        }

        // ==========================================
        // TASKS BUTTON
        // ==========================================
        private void button4_Click(object sender, EventArgs e)
        {
            listBoxMain.Items.Clear();
            listBoxMain.Items.Add("=== All Tasks ===");

            List<Task> tasks =
                taskController.GetAllTasks();

            if (tasks.Count == 0)
            {
                listBoxMain.Items.Add("No tasks found!");
                return;
            }

            foreach (Task t in tasks)
            {
                listBoxMain.Items.Add(
                    t.Id + ". " + t.Description +
                    " - State: " + t.GetStateName() +
                    " - Priority: " + t.Priority);
            }
        }

        // ==========================================
        // TEAM BUTTON
        // ==========================================
        private void button5_Click(object sender, EventArgs e)
        {
            listBoxMain.Items.Clear();
            listBoxMain.Items.Add("=== Project Team ===");
            listBoxMain.Items.Add("Select a project first!");
        }

        // ==========================================
        // LISTBOX
        // ==========================================
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }
    }
}