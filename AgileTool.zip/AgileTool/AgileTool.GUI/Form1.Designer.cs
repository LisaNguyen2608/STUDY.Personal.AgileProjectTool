﻿namespace AgileTool.GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.btnPerson = new System.Windows.Forms.Button();
            this.btnStories = new System.Windows.Forms.Button();
            this.btnTasks = new System.Windows.Forms.Button();
            this.btnTeam = new System.Windows.Forms.Button();
            this.listBoxMain = new System.Windows.Forms.ListBox();
            this.btnProject = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPerson
            // 
            resources.ApplyResources(this.btnPerson, "btnPerson");
            this.btnPerson.Name = "btnPerson";
            this.btnPerson.UseVisualStyleBackColor = true;
            this.btnPerson.Click += new System.EventHandler(this.btnPersons_Click);
            // 
            // btnStories
            // 
            resources.ApplyResources(this.btnStories, "btnStories");
            this.btnStories.Name = "btnStories";
            this.btnStories.UseVisualStyleBackColor = true;
            this.btnStories.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnTasks
            // 
            resources.ApplyResources(this.btnTasks, "btnTasks");
            this.btnTasks.Name = "btnTasks";
            this.btnTasks.UseVisualStyleBackColor = true;
            this.btnTasks.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnTeam
            // 
            resources.ApplyResources(this.btnTeam, "btnTeam");
            this.btnTeam.Name = "btnTeam";
            this.btnTeam.UseVisualStyleBackColor = true;
            this.btnTeam.Click += new System.EventHandler(this.button5_Click);
            // 
            // listBoxMain
            // 
            resources.ApplyResources(this.listBoxMain, "listBoxMain");
            this.listBoxMain.FormattingEnabled = true;
            this.listBoxMain.Name = "listBoxMain";
            this.listBoxMain.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // btnProject
            // 
            resources.ApplyResources(this.btnProject, "btnProject");
            this.btnProject.Name = "btnProject";
            this.btnProject.UseVisualStyleBackColor = true;
            this.btnProject.Click += new System.EventHandler(this.btnProject_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnProject);
            this.Controls.Add(this.listBoxMain);
            this.Controls.Add(this.btnTeam);
            this.Controls.Add(this.btnTasks);
            this.Controls.Add(this.btnStories);
            this.Controls.Add(this.btnPerson);
            this.Name = "Agile Project";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnPerson;
        private System.Windows.Forms.Button btnStories;
        private System.Windows.Forms.Button btnTasks;
        private System.Windows.Forms.Button btnTeam;
        private System.Windows.Forms.ListBox listBoxMain;
        private System.Windows.Forms.Button btnProject;
    }
}

