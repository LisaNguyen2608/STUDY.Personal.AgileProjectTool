﻿using AgileTool.Models;
using AgileTool.Data;
using System;
using System.Collections.Generic;

namespace AgileTool.Controllers
{
    public class UserStoryController
    {
        // Connect to database through DataService
        private DataService dataService = new DataService();

        // ADD a new story to database
        public void AddStory(int projectId, string description, int priority)
        {
            if (string.IsNullOrEmpty(description))
            {
                Console.WriteLine("Description cannot be empty!");
                return;
            }

            dataService.AddUserStory(projectId, description, priority);
            Console.WriteLine("User story added successfully!");
        }

        // LIST all stories from database
        public void ListStories()
        {
            List<UserStory> stories = dataService.GetAllUserStories();

            if (stories.Count == 0)
            {
                Console.WriteLine("No stories found!");
                return;
            }

            Console.WriteLine("=== All User Stories ===");
            foreach (UserStory s in stories)
            {
                Console.WriteLine("─────────────────");
                Console.WriteLine("ID:          " + s.Id);
                Console.WriteLine("Description: " + s.Description);
                Console.WriteLine("Priority:    " + s.Priority);
                Console.WriteLine("State:       " + s.GetStateName());
            }
            Console.WriteLine("─────────────────");
        }

        public List<UserStory> GetAllStories()
        {
            return dataService.GetAllUserStories();
        }
    }
}