﻿using AgileTool.Models;
using AgileTool.Data;
using System;
using System.Collections.Generic;

namespace AgileTool.Controllers
{
    public class TaskController
    {
        private DataService dataService = new DataService();

        public void AddTask(int userStoryId, string description,
                           int priority, int difficulty)
        {
            if (string.IsNullOrEmpty(description))
            {
                Console.WriteLine("Description cannot be empty!");
                return;
            }
            dataService.AddTask(userStoryId, description,
                               priority, difficulty, "General");
            Console.WriteLine("Task added successfully!");
        }

        public void ListTasks()
        {
            List<Task> tasks = dataService.GetAllTasks();

            if (tasks.Count == 0)
            {
                Console.WriteLine("No tasks found!");
                return;
            }

            Console.WriteLine("=== All Tasks ===");
            foreach (Task t in tasks)
            {
                Console.WriteLine("─────────────────");
                Console.WriteLine("ID:          " + t.Id);
                Console.WriteLine("Description: " + t.Description);
                Console.WriteLine("Priority:    " + t.Priority);
                Console.WriteLine("Difficulty:  " + t.Difficulty);
                Console.WriteLine("State:       " + t.GetStateName());
            }
            Console.WriteLine("─────────────────");
        }

        public List<Task> GetAllTasks()
        {
            return dataService.GetAllTasks();
        }
    


    public void MoveTaskState(int taskId, int newState)
        {
            Task task = dataService.GetTaskById(taskId);
            if (task == null)
            {
                Console.WriteLine("Task not found!");
                return;
            }

            UserStory story = dataService.GetUserStoryById(task.UserStoryId);
            if (story.State != 2)
            {
                Console.WriteLine("Task can only move when the user story is IN SPRINT.");
                return;
            }

            // Check allowed transitions
            if (Math.Abs(newState - task.State) != 1)
            {
                Console.WriteLine("Invalid state transition!");
                return;
            }

            // Dependency rule
            if (newState == 2) // moving to In Process
            {
                if (!dataService.AreDependencyTasksDone(story.Id))
                {
                    Console.WriteLine("Cannot move task to IN PROCESS because dependency tasks are not done.");
                    return;
                }
            }

            dataService.UpdateTaskState(taskId, newState);
            Console.WriteLine("Task state updated!");
        }

    } 
}