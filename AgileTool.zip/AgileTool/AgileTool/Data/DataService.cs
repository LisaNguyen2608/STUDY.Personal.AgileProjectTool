﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using AgileTool.Models;

namespace AgileTool.Data
{
    class DataService
    {
        private SqlConnection myConnection;

        public DataService()
        {
            String connstr;
            connstr = @"Server=(localdb)\MSSQLLocalDB;
                        Database=AgileTool;
                        Trusted_Connection=True;";
            myConnection = new SqlConnection();
            myConnection.ConnectionString = connstr;
            myConnection.Open();
        }

        // ==========================================
        // PROJECT METHODS
        // ==========================================

        // Get ALL projects
        public List<Project> GetAllProjects()
        {
            List<Project> projectList = new List<Project>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, Name, Description FROM PROJECT";
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                int id = Convert.ToInt32(myReader["Id"].ToString());
                string name = myReader["Name"].ToString();
                string description = myReader["Description"].ToString();

                Project p = new Project(id, name, description);
                projectList.Add(p);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return projectList;
        }

        // Add NEW project
        public void AddProject(string name, string description)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO PROJECT (Name, Description) " +
                                    "VALUES (@Name, @Description)";
            myCommand.Parameters.AddWithValue("@Name", name);
            myCommand.Parameters.AddWithValue("@Description", description);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // ==========================================
        // USER STORY METHODS
        // ==========================================

        // Get ALL user stories
        public List<UserStory> GetAllUserStories()
        {
            List<UserStory> storyList = new List<UserStory>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, ProjectId, Description, " +
                                    "State, Priority FROM USER_STORY";
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                UserStory s = new UserStory(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["ProjectId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"])
                );
                storyList.Add(s);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return storyList;
        }

        // Get user stories by project
        public List<UserStory> GetUserStoriesByProject(int projectId)
        {
            List<UserStory> storyList = new List<UserStory>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, ProjectId, Description, " +
                                    "State, Priority FROM USER_STORY " +
                                    "WHERE ProjectId = @ProjectId";
            myCommand.Parameters.AddWithValue("@ProjectId", projectId);
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                UserStory s = new UserStory(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["ProjectId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"])
                );
                storyList.Add(s);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return storyList;
        }

        // Get ONE user story by Id
        public UserStory GetUserStoryById(int storyId)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, ProjectId, Description, " +
                                    "State, Priority FROM USER_STORY " +
                                    "WHERE Id = @Id";
            myCommand.Parameters.AddWithValue("@Id", storyId);
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            UserStory story = null;
            if (myReader.Read())
            {
                story = new UserStory(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["ProjectId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"])
                );
            }
            myReader.Close();
            return story;
        }

        // Add NEW user story
        public void AddUserStory(int projectId, string description, int priority)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO USER_STORY " +
                                    "(ProjectId, Description, State, Priority) " +
                                    "VALUES (@ProjectId, @Description, @State, @Priority)";
            myCommand.Parameters.AddWithValue("@ProjectId", projectId);
            myCommand.Parameters.AddWithValue("@Description", description);
            myCommand.Parameters.AddWithValue("@Priority", priority);
            myCommand.Parameters.AddWithValue("@State", 1);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // Update story state
        public void UpdateStoryState(int storyId, int newState)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "UPDATE USER_STORY SET State = @State " +
                                    "WHERE Id = @Id";
            myCommand.Parameters.AddWithValue("@State", newState);
            myCommand.Parameters.AddWithValue("@Id", storyId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // ==========================================
        // TASK METHODS
        // ==========================================

        // Get ALL tasks
        public List<Task> GetAllTasks()
        {
            List<Task> taskList = new List<Task>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, UserStoryId, Description, " +
                                    "State, Priority, Difficulty, Category " +
                                    "FROM TASK";
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                Task t = new Task(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["UserStoryId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"]),
                    Convert.ToInt32(myReader["Difficulty"]),
                    myReader["Category"].ToString()
                );
                taskList.Add(t);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return taskList;
        }

        // Get tasks by user story
        public List<Task> GetTasksByUserStory(int userStoryId)
        {
            List<Task> taskList = new List<Task>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, UserStoryId, Description, " +
                                    "State, Priority, Difficulty, Category " +
                                    "FROM TASK WHERE UserStoryId = @UserStoryId";
            myCommand.Parameters.AddWithValue("@UserStoryId", userStoryId);
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                Task t = new Task(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["UserStoryId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"]),
                    Convert.ToInt32(myReader["Difficulty"]),
                    myReader["Category"].ToString()
                );
                taskList.Add(t);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return taskList;
        }

        public void UpdateUserStoryState(int storyId, int newState)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = myConnection;
            cmd.CommandText = "UPDATE USER_STORY SET State = @state WHERE Id = @id";
            cmd.Parameters.AddWithValue("@state", newState);
            cmd.Parameters.AddWithValue("@id", storyId);
            cmd.ExecuteNonQuery();
        }


        // Get ONE task by Id
        public Task GetTaskById(int taskId)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, UserStoryId, Description, " +
                                    "State, Priority, Difficulty, Category " +
                                    "FROM TASK WHERE Id = @Id";
            myCommand.Parameters.AddWithValue("@Id", taskId);
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            Task task = null;
            if (myReader.Read())
            {
                task = new Task(
                    Convert.ToInt32(myReader["Id"]),
                    Convert.ToInt32(myReader["UserStoryId"]),
                    myReader["Description"].ToString(),
                    Convert.ToInt32(myReader["State"]),
                    Convert.ToInt32(myReader["Priority"]),
                    Convert.ToInt32(myReader["Difficulty"]),
                    myReader["Category"].ToString()
                );
            }
            myReader.Close();
            return task;
        }

        // Add NEW task
        public void AddTask(int userStoryId, string description,
                           int priority, int difficulty, string category)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO TASK " +
                                    "(UserStoryId, Description, State, " +
                                    "Priority, Difficulty, Category) " +
                                    "VALUES (@UserStoryId, @Description, 1, " +
                                    "@Priority, @Difficulty, @Category)";
            myCommand.Parameters.AddWithValue("@UserStoryId", userStoryId);
            myCommand.Parameters.AddWithValue("@Description", description);
            myCommand.Parameters.AddWithValue("@Priority", priority);
            myCommand.Parameters.AddWithValue("@Difficulty", difficulty);
            myCommand.Parameters.AddWithValue("@Category", category);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // Update task state
        public void UpdateTaskState(int taskId, int newState)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "UPDATE TASK SET State = @State " +
                                    "WHERE Id = @Id";
            myCommand.Parameters.AddWithValue("@State", newState);
            myCommand.Parameters.AddWithValue("@Id", taskId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // Update task priority
        public void UpdateTaskPriority(int taskId, int newPriority)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "UPDATE TASK SET Priority = @Priority " +
                                    "WHERE Id = @Id";
            myCommand.Parameters.AddWithValue("@Priority", newPriority);
            myCommand.Parameters.AddWithValue("@Id", taskId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        public List<int> GetDependencies(int storyId)
        {
            List<int> deps = new List<int>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT DependsOnStoryId FROM STORY_DEPENDENCY WHERE StoryId = @StoryId";
            myCommand.Parameters.AddWithValue("@StoryId", storyId);

            SqlDataReader myReader = myCommand.ExecuteReader();
            while (myReader.Read())
            {
                deps.Add(Convert.ToInt32(myReader["DependsOnStoryId"]));
            }
            myReader.Close();

            return deps;
        }



        public bool AreDependencyTasksDone(int storyId)
        {
            // Get all stories this one depends on
            List<int> deps = GetDependencies(storyId);

            foreach (int depId in deps)
            {
                List<Task> tasks = GetTasksByUserStory(depId);
                foreach (Task t in tasks)
                {
                    if (t.State != 3) return false;
                }
            }

            return true;
        }


        // ==========================================
        // PERSON METHODS
        // ==========================================

        // Get ALL persons
        public List<Person> GetAllPersons()
        {
            List<Person> personList = new List<Person>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT Id, Name, Role FROM PERSON";
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                int id = Convert.ToInt32(myReader["Id"].ToString());
                string name = myReader["Name"].ToString();
                string role = myReader["Role"].ToString();

                Person p = new Person(id, name, role);
                personList.Add(p);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return personList;
        }

        // Add NEW person
        public void AddPerson(string name, string role)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO PERSON (Name, Role) " +
                                    "VALUES (@Name, @Role)";
            myCommand.Parameters.AddWithValue("@Name", name);
            myCommand.Parameters.AddWithValue("@Role", role);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // ==========================================
        // PROJECT TEAM METHODS
        // ==========================================

        // Get persons by project
        public List<Person> GetPersonsByProject(int projectId)
        {
            List<Person> personList = new List<Person>();

            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "SELECT P.Id, P.Name, P.Role " +
                                    "FROM PERSON P " +
                                    "INNER JOIN PROJECT_TEAM PT " +
                                    "ON P.Id = PT.PersonId " +
                                    "WHERE PT.ProjectId = @ProjectId";
            myCommand.Parameters.AddWithValue("@ProjectId", projectId);
            myCommand.CommandType = CommandType.Text;

            SqlDataReader myReader = myCommand.ExecuteReader();
            bool notEoF = myReader.Read();
            while (notEoF)
            {
                Person p = new Person(
                    Convert.ToInt32(myReader["Id"]),
                    myReader["Name"].ToString(),
                    myReader["Role"].ToString()
                );
                personList.Add(p);
                notEoF = myReader.Read();
            }
            myReader.Close();
            return personList;
        }

        // Add person to project
        public void AddPersonToProject(int projectId, int personId)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO PROJECT_TEAM " +
                                    "(ProjectId, PersonId) " +
                                    "VALUES (@ProjectId, @PersonId)";
            myCommand.Parameters.AddWithValue("@ProjectId", projectId);
            myCommand.Parameters.AddWithValue("@PersonId", personId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // ==========================================
        // TASK ASSIGNMENT METHODS
        // ==========================================

        // Assign person to task
        public void AssignPersonToTask(int taskId, int personId)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "INSERT INTO TASK_ASSIGNMENT " +
                                    "(TaskId, PersonId) " +
                                    "VALUES (@TaskId, @PersonId)";
            myCommand.Parameters.AddWithValue("@TaskId", taskId);
            myCommand.Parameters.AddWithValue("@PersonId", personId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }

        // Remove person from task
        public void RemovePersonFromTask(int taskId, int personId)
        {
            SqlCommand myCommand = new SqlCommand();
            myCommand.Connection = myConnection;
            myCommand.CommandText = "DELETE FROM TASK_ASSIGNMENT " +
                                    "WHERE TaskId = @TaskId " +
                                    "AND PersonId = @PersonId";
            myCommand.Parameters.AddWithValue("@TaskId", taskId);
            myCommand.Parameters.AddWithValue("@PersonId", personId);
            myCommand.CommandType = CommandType.Text;
            myCommand.ExecuteNonQuery();
        }
    }
}
